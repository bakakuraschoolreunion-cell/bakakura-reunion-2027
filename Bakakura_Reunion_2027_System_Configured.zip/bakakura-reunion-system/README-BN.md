# বাঁকাকুড়া গ্র্যান্ড রিইউনিয়ন ২০২৭ — রেজিস্ট্রেশন সিস্টেম

এটি একটি responsive Bangla registration website ও multi-admin dashboard-এর starter project। এটি এখনো কোনো public hosting বা live database-এ deploy করা হয়নি।

## কী আছে
- শিক্ষার্থীদের বাংলা রেজিস্ট্রেশন ফরম
- SSC batch 1991–2025, T-shirt size S–3XL
- বিকাশ/নগদ payment method, sender number ও transaction ID
- Pending / Approved / Rejected workflow
- Admin login (Supabase Auth)
- একাধিক অ্যাডমিন
- অনুমোদনের সময় স্বয়ংক্রিয় unique token: `BGR27-00001` ইত্যাদি
- Dashboard summary, search, filter, CSV export ও size report
- Public visitor অন্যের registration দেখতে পারে না (RLS)

## ১) Supabase project তৈরি
1. https://supabase.com এ একটি project তৈরি করুন।
2. Project-এর SQL Editor খুলে `supabase/schema.sql`-এর সম্পূর্ণ SQL রান করুন।
3. Project Settings → API Keys থেকে Publishable key (অথবা legacy anon public key) নিন।
4. এই প্যাকেজে `.env` ফাইলটি আপনার দেওয়া Project URL ও Publishable key দিয়ে আগে থেকেই কনফিগার করা আছে। Project URL-এ `/rest/v1/` যোগ করবেন না; শুধু project root URL ব্যবহার করুন।
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
5. Supabase Authentication → Providers-এ Email provider চালু রাখুন। Admin account-গুলোর জন্য public sign-up বন্ধ রাখুন বা invite-only পদ্ধতি ব্যবহার করুন।
6. শিক্ষার্থীর ফরমে সফল insert-এর পরে কোনো ব্যক্তিগত রেজিস্ট্রেশন row পড়া হয় না; তাই success screen-এ ব্যক্তিগত database ID দেখানো হয় না।

## ২) প্রথম ও পরবর্তী অ্যাডমিন যোগ
1. Supabase Dashboard → Authentication → Users থেকে প্রতিটি organizer-এর account তৈরি/invite করুন।
2. সংশ্লিষ্ট user-এর UUID কপি করুন।
3. SQL Editor-এ নিচের query চালান (UUID ও নাম বদলে):
```sql
insert into public.admin_users (user_id, display_name)
values ('PASTE-AUTH-USER-UUID-HERE', 'প্রধান অ্যাডমিন');
```
প্রতিটি অ্যাডমিনের জন্য আলাদা row যোগ করুন। Admin তালিকায় নেই এমন কেউ dashboard-এ লগইন করলেও registration data পড়তে পারবে না।

## ৩) লোকালি চালানো
Node.js 20 বা তার নতুন সংস্করণ ইনস্টল করে project folder-এ:
```bash
npm install
npm run dev
```
Production build:
```bash
npm run build
```
তৈরি হওয়া `dist` folder Netlify, Vercel বা অন্য static hosting-এ deploy করা যাবে। Hosting-এ একই দুইটি environment variable সেট করতে হবে।

## ৪) গুরুত্বপূর্ণ নিরাপত্তা/প্রকাশের আগে যাচাই
- `anon` key browser-এ থাকা স্বাভাবিক; `service_role` key কখনো frontend-এ দেবেন না।
- Admin-দের শক্তিশালী password ও 2FA ব্যবহার করতে বলুন।
- প্রথমে test registration দিয়ে submit, pending, approve, token, reject, CSV export যাচাই করুন।
- Public form-এ spam protection / CAPTCHA এবং duplicate transaction ID প্রতিরোধ যোগ করা উচিত।
- বর্তমান starter-এ student confirmation screen-এ submission reference দেখায়; token approval-এর পর admin dashboard-এ দেখা যায়। SMS/email notification এখনো সংযুক্ত নয়।
- Payment screenshot upload, printable receipt, edit/delete controls ও audit log পরবর্তী ধাপে যোগ করা যেতে পারে।
- Live deployment-এর আগে privacy notice, data retention policy এবং event organizer-এর অনুমোদন নিশ্চিত করুন।

## ৫) মূল তথ্য
- নিবন্ধন ফি: ১,০০০ টাকা
- বিকাশ (Personal): 01712308190 — আওলাদ হোসেন
- নগদ (Personal): 01946292622 — মতিউর রহমান
- যোগাযোগ: মতিউর রহমান 01946292622; আওলাদ হোসেন 01712308190; পারভেজ মোশাররফ 01990560853; আনিসুর রহমান আনিস 01972578562
- নিবন্ধন সময়: ৫ নভেম্বর ২০২৬ – ১৫ ফেব্রুয়ারি ২০২৭
