import React, {useEffect, useMemo, useState} from 'react';
import {createRoot} from 'react-dom/client';
import {createClient} from '@supabase/supabase-js';
import {Users, ShieldCheck, Search, LogOut, Download, Check, X, RefreshCw, Menu, ArrowLeft, CreditCard, Shirt, ClipboardList} from 'lucide-react';
import './style.css';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = SUPABASE_URL && KEY ? createClient(SUPABASE_URL, KEY) : null;
const sizes = ['S','M','L','XL','XXL','3XL'];
const years = Array.from({length:35},(_,i)=>String(1991+i));
const money = n => new Intl.NumberFormat('bn-BD').format(n || 0);
const sampleMode = !supabase;

function Header({admin=false,onAdmin,onHome}) {
  return <header className="top"><div className="brand"><div className="crest">ব</div><div><b>বাঁকাকুড়া গ্র্যান্ড</b><small>রিইউনিয়ন ২০২৭</small></div></div><button className="ghost" onClick={admin?onHome:onAdmin}>{admin?<><ArrowLeft size={17}/> ফরমে ফিরুন</>:<><ShieldCheck size={17}/> অ্যাডমিন</>}</button></header>
}
function Field({label,children,required=false}) {return <label className="field"><span>{label}{required&&<i> *</i>}</span>{children}</label>}
function Registration({onAdmin}) {
 const [form,setForm]=useState({full_name:'',ssc_batch:'',shirt_size:'',payment_method:'বিকাশ',payment_number:'',transaction_id:'',phone:''});
 const [busy,setBusy]=useState(false),[result,setResult]=useState(null),[error,setError]=useState('');
 const change=(k,v)=>setForm(p=>({...p,[k]:v}));
 async function submit(e){e.preventDefault();setError('');setBusy(true);
  if(sampleMode){setResult({registration_id:'DEMO-2027-001',status:'pending'});setBusy(false);return;}
  const {error}=await supabase.from('registrations').insert({...form,ssc_batch:Number(form.ssc_batch)});
  if(error)setError(error.message);else setResult({registration_id:'জমা সফল',status:'pending'});
  setBusy(false);
 }
 if(result)return <main className="wrap narrow"><div className="success"><div className="successIcon"><Check size={32}/></div><h2>আবেদন গ্রহণ করা হয়েছে</h2><p>আপনার আবেদনটি পেমেন্ট যাচাইয়ের অপেক্ষায় আছে। অনুমোদনের পর টোকেন তৈরি হবে।</p><div className="ticket"><small>আবেদনের অবস্থা</small><strong>{result.registration_id}</strong><small>পেমেন্ট যাচাই শেষে অনুমোদন ও টোকেন প্রদান করা হবে</small></div><button className="primary full" onClick={()=>{setResult(null);setForm({full_name:'',ssc_batch:'',shirt_size:'',payment_method:'বিকাশ',payment_number:'',transaction_id:'',phone:''})}}>নতুন আবেদন</button></div></main>;
 return <main className="wrap">
  <section className="hero"><div className="heroTag">স্মৃতির টানে • শেকড়ের বন্ধনে</div><h1>বাঁকাকুড়া গ্র্যান্ড<br/>রিইউনিয়ন ২০২৭</h1><p>ফেলে আসা বন্ধু, প্রিয় ক্যাম্পাস আর সোনালি দিনগুলোকে আবার একসঙ্গে উদযাপন করি।</p><div className="fee"><span>নিবন্ধন ফি</span><b>৳ ১,০০০</b><small>১৯৯১–২০২৫ ব্যাচের প্রাক্তন শিক্ষার্থী</small></div></section>
  <form className="panel" onSubmit={submit}><div className="sectionTitle"><Users/><div><h2>শিক্ষার্থীর তথ্য</h2><p>সঠিক তথ্য দিয়ে ফরমটি পূরণ করুন</p></div></div>
   <div className="grid">
    <Field label="পূর্ণ নাম" required><input required value={form.full_name} onChange={e=>change('full_name',e.target.value)} placeholder="আপনার পূর্ণ নাম"/></Field>
    <Field label="এসএসসি ব্যাচ" required><select required value={form.ssc_batch} onChange={e=>change('ssc_batch',e.target.value)}><option value="">ব্যাচ নির্বাচন করুন</option>{years.map(y=><option key={y}>{y}</option>)}</select></Field>
    <Field label="টি-শার্ট সাইজ" required><select required value={form.shirt_size} onChange={e=>change('shirt_size',e.target.value)}><option value="">সাইজ নির্বাচন করুন</option>{sizes.map(s=><option key={s}>{s}</option>)}</select></Field>
    <Field label="যোগাযোগ নম্বর" required><input required inputMode="tel" pattern="[0-9+ -]{10,16}" value={form.phone} onChange={e=>change('phone',e.target.value)} placeholder="01XXXXXXXXX"/></Field>
   </div>
   <div className="sectionTitle sub"><CreditCard/><div><h2>পেমেন্ট তথ্য</h2><p>১,০০০ টাকা পাঠিয়ে তথ্য দিন</p></div></div>
   <div className="paymentInfo"><div><b>বিকাশ (Personal)</b><strong>01712308190</strong><small>আওলাদ হোসেন</small></div><div><b>নগদ (Personal)</b><strong>01946292622</strong><small>মতিউর রহমান</small></div></div>
   <div className="grid">
    <Field label="পেমেন্ট মাধ্যম" required><select value={form.payment_method} onChange={e=>change('payment_method',e.target.value)}><option>বিকাশ</option><option>নগদ</option></select></Field>
    <Field label="যে নম্বর থেকে টাকা পাঠিয়েছেন" required><input required inputMode="tel" value={form.payment_number} onChange={e=>change('payment_number',e.target.value)} placeholder="01XXXXXXXXX"/></Field>
    <Field label="ট্রানজেকশন আইডি / পেমেন্ট রেফারেন্স" required><input required value={form.transaction_id} onChange={e=>change('transaction_id',e.target.value)} placeholder="Transaction ID"/></Field>
   </div>
   {error&&<div className="error">{error}</div>}
   {sampleMode&&<div className="notice">প্রিভিউ মোড: Supabase সংযুক্ত না থাকায় জমা দেওয়া তথ্য সংরক্ষিত হবে না।</div>}
   <button className="primary full" disabled={busy}>{busy?'জমা হচ্ছে…':'নিবন্ধন জমা দিন'}</button><p className="fine">নিবন্ধন জমা দেওয়ার পর অ্যাডমিন পেমেন্ট যাচাই করবেন। অনুমোদনের পর আপনার টোকেন তৈরি হবে।</p>
  </form>
  <section className="contact"><h3>প্রয়োজনে যোগাযোগ</h3><p>মতিউর রহমান: 01946292622</p><p>আওলাদ হোসেন: 01712308190</p><p>পারভেজ মোশাররফ: 01990560853</p><p>আনিসুর রহমান আনিস: 01972578562</p><small>নিবন্ধন: ৫ নভেম্বর ২০২৬ – ১৫ ফেব্রুয়ারি ২০২৭</small></section>
  <footer>© বাঁকাকুড়া গ্র্যান্ড রিইউনিয়ন ২০২৭</footer>
 </main>
}
function Admin(){
 const [session,setSession]=useState(null),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[rows,setRows]=useState([]),[loading,setLoading]=useState(false),[err,setErr]=useState(''),[search,setSearch]=useState(''),[filter,setFilter]=useState('all');
 useEffect(()=>{if(!supabase)return;supabase.auth.getSession().then(({data})=>setSession(data.session));const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s));return()=>subscription.unsubscribe()},[]);
 async function load(){if(!supabase||!session)return;setLoading(true);const {data,error}=await supabase.from('registrations').select('*').order('created_at',{ascending:false});if(error)setErr(error.message);else setRows(data||[]);setLoading(false)}
 useEffect(()=>{load()},[session]);
 async function login(e){e.preventDefault();setErr('');const {error}=await supabase.auth.signInWithPassword({email,password});if(error)setErr(error.message)}
 async function update(id,action){setErr('');const rpc=action==='approve'?'approve_registration': 'reject_registration';const {error}=await supabase.rpc(rpc,{registration_uuid:id});if(error)setErr(error.message);else load()}
 const filtered=useMemo(()=>rows.filter(r=>(filter==='all'||r.status===filter)&&[r.full_name,r.phone,r.ssc_batch,r.token].join(' ').toLowerCase().includes(search.toLowerCase())),[rows,filter,search]);
 const approved=rows.filter(r=>r.status==='approved');
 function csv(){const cols=['token','full_name','ssc_batch','shirt_size','phone','payment_method','payment_number','transaction_id','status'];const data=[cols.join(','),...filtered.map(r=>cols.map(c=>'"'+String(r[c]??'').replaceAll('"','""')+'"').join(','))].join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+data],{type:'text/csv;charset=utf-8'}));a.download='bakakura-registrations.csv';a.click()}
 if(!supabase)return <main className="wrap narrow"><div className="panel"><h2>অ্যাডমিন ড্যাশবোর্ড</h2><div className="notice">Supabase সংযোগের জন্য .env কনফিগার করা হয়েছে। প্রথমে SQL schema চালান এবং অন্তত একজন অ্যাডমিন তৈরি করে admin_users-এ যুক্ত করুন।</div></div></main>;
 if(!session)return <main className="wrap narrow"><form className="panel login" onSubmit={login}><div className="sectionTitle"><ShieldCheck/><div><h2>অ্যাডমিন লগইন</h2><p>অনুমোদিত আয়োজকদের জন্য</p></div></div><Field label="ইমেইল"><input type="email" required value={email} onChange={e=>setEmail(e.target.value)}/></Field><Field label="পাসওয়ার্ড"><input type="password" required value={password} onChange={e=>setPassword(e.target.value)}/></Field>{err&&<div className="error">{err}</div>}<button className="primary full">লগইন</button></form></main>;
 return <main className="wrap adminWrap"><div className="dashHead"><div><h1>রেজিস্ট্রেশন ড্যাশবোর্ড</h1><p>{session.user.email}</p></div><button className="ghost" onClick={()=>supabase.auth.signOut()}><LogOut size={16}/> লগআউট</button></div>
  <div className="stats"><div className="stat"><Users/><b>{money(rows.length)}</b><small>মোট আবেদন</small></div><div className="stat"><ShieldCheck/><b>{money(approved.length)}</b><small>অনুমোদিত</small></div><div className="stat"><CreditCard/><b>{money(rows.filter(r=>r.status==='pending').length)}</b><small>যাচাই বাকি</small></div><div className="stat"><Shirt/><b>{money(approved.length*1000)}</b><small>অনুমোদিত ফি (টাকা)</small></div></div>
  <div className="panel"><div className="toolbar"><div className="search"><Search/><input placeholder="নাম, ফোন, ব্যাচ বা টোকেন খুঁজুন" value={search} onChange={e=>setSearch(e.target.value)}/></div><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">সব আবেদন</option><option value="pending">যাচাই বাকি</option><option value="approved">অনুমোদিত</option><option value="rejected">বাতিল</option></select><button className="outline" onClick={load}><RefreshCw size={16}/> রিফ্রেশ</button><button className="outline" onClick={csv}><Download size={16}/> CSV</button></div>
  {err&&<div className="error">{err}</div>}{loading?<p>লোড হচ্ছে…</p>:<div className="tableWrap"><table><thead><tr><th>নাম / টোকেন</th><th>ব্যাচ</th><th>ফোন</th><th>সাইজ</th><th>পেমেন্ট</th><th>অবস্থা</th><th>অ্যাকশন</th></tr></thead><tbody>{filtered.map(r=><tr key={r.id}><td><b>{r.full_name}</b><small>{r.token||'টোকেন হয়নি'}</small></td><td>{r.ssc_batch}</td><td>{r.phone}</td><td>{r.shirt_size}</td><td><small>{r.payment_method} · {r.payment_number}</small><small>{r.transaction_id}</small></td><td><span className={'pill '+r.status}>{r.status==='approved'?'অনুমোদিত':r.status==='rejected'?'বাতিল':'যাচাই বাকি'}</span></td><td>{r.status==='pending'?<div className="actions"><button title="অনুমোদন" className="approve" onClick={()=>update(r.id,'approve')}><Check size={16}/></button><button title="বাতিল" className="reject" onClick={()=>update(r.id,'reject')}><X size={16}/></button></div>:<span className="muted">—</span>}</td></tr>)}</tbody></table>{!filtered.length&&<p className="empty">কোনো আবেদন পাওয়া যায়নি</p>}</div>}</div>
  <div className="panel"><h3>টি-শার্ট সাইজ রিপোর্ট (অনুমোদিত)</h3><div className="sizes">{sizes.map(s=><div><b>{s}</b><strong>{money(approved.filter(r=>r.shirt_size===s).length)}</strong></div>)}</div></div>
 </main>
}
function App(){const [page,setPage]=useState('form');return <><Header admin={page==='admin'} onAdmin={()=>setPage('admin')} onHome={()=>setPage('form')}/>{page==='admin'?<Admin/>:<Registration onAdmin={()=>setPage('admin')}/>}</>}
createRoot(document.getElementById('root')).render(<App/>);