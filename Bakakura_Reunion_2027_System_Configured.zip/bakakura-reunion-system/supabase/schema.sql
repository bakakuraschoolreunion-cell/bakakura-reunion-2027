-- Bakakura Grand Reunion 2027
-- Run this in Supabase SQL Editor before deploying the app.
create extension if not exists pgcrypto;

create table if not exists public.registrations (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  ssc_batch integer not null check (ssc_batch between 1991 and 2025),
  shirt_size text not null check (shirt_size in ('S','M','L','XL','XXL','3XL')),
  payment_method text not null check (payment_method in ('বিকাশ','নগদ')),
  payment_number text not null,
  transaction_id text not null,
  phone text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  token text unique,
  created_at timestamptz not null default now(),
  approved_at timestamptz,
  approved_by uuid references auth.users(id)
);

create unique index if not exists registrations_transaction_id_unique on public.registrations (lower(trim(transaction_id)));

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

alter table public.registrations enable row level security;
alter table public.admin_users enable row level security;

create or replace function public.is_reunion_admin()
returns boolean language sql stable security definer
set search_path = public
as $$ select exists(select 1 from public.admin_users where user_id = auth.uid()); $$;

-- Students may submit a registration, but cannot read or change registrations.
create policy "public can submit registration"
on public.registrations for insert to anon, authenticated
with check (status = 'pending' and token is null and approved_at is null and approved_by is null);

create policy "admins can read registrations"
on public.registrations for select to authenticated
using (public.is_reunion_admin());

-- Registration status changes are performed only through the approval/rejection RPCs.

create policy "admins can read own admin record"
on public.admin_users for select to authenticated
using (user_id = auth.uid());

-- Sequential token is issued only by the approval RPC.
create sequence if not exists public.reunion_token_seq start 1;

create or replace function public.approve_registration(registration_uuid uuid)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare new_token text;
begin
  if not public.is_reunion_admin() then
    raise exception 'অনুমোদিত অ্যাডমিন নন';
  end if;
  update public.registrations
     set status = 'approved',
         token = coalesce(token, 'BGR27-' || lpad(nextval('public.reunion_token_seq')::text, 5, '0')),
         approved_at = coalesce(approved_at, now()),
         approved_by = auth.uid()
   where id = registration_uuid and status = 'pending'
   returning token into new_token;
  if new_token is null then
    select token into new_token from public.registrations where id = registration_uuid and status = 'approved';
  end if;
  if new_token is null then raise exception 'আবেদনটি পাওয়া যায়নি অথবা ইতিমধ্যে নিষ্পত্তি হয়েছে'; end if;
  return new_token;
end;
$$;

create or replace function public.reject_registration(registration_uuid uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_reunion_admin() then
    raise exception 'অনুমোদিত অ্যাডমিন নন';
  end if;
  update public.registrations set status='rejected'
   where id=registration_uuid and status='pending';
  if not found then raise exception 'আবেদনটি পাওয়া যায়নি অথবা ইতিমধ্যে নিষ্পত্তি হয়েছে'; end if;
  return true;
end;
$$;

revoke all on function public.approve_registration(uuid) from public;
revoke all on function public.reject_registration(uuid) from public;
grant execute on function public.approve_registration(uuid) to authenticated;
grant execute on function public.reject_registration(uuid) to authenticated;
grant usage, select on sequence public.reunion_token_seq to authenticated;

-- IMPORTANT: Create each organizer in Supabase Authentication first,
-- then insert that user's UUID into admin_users. See README.
